#include "Btree.h"
#include <iostream>
bool Btree::areMirrors(TnodePtr root1, TnodePtr root2){
    /* If either tree is empty, both must be. */
    if(!root1){
        if(!root2)
            return true;
        else
            return false;
    }else{
        if(!root2)
            return false;
    }

    /* Neither tree is empty. The roots must have equal values. */
    if(root1->val != root2->val)
        return false;

    /* To see if they are mirrors, we need to check whether the left 
    sub-tree of the first tree mirrors the right sub-tree of the second tree 
    and vice-versa. */
    return areMirrors(root1->left, root2->right) && areMirrors(root1->right, root2->left);
}

TnodePtr& Btree::getRoot(){
    return root;
}

void Btree::buildBtree(int val[], int n, int &k, TnodePtr &node){
    if(val[k] == -1 || k>=n){    //空node
        node = 0;
        return;
    }

    node = new Tnode;
    node->val = val[k++];
    std::cout << "new node(" << node->val << ") built" << std::endl;

    buildBtree(val, n, k, node->left);
    k++;
    buildBtree(val, n, k, node->right);
}

void Btree::deleteBtree(TnodePtr &node){
    if(!node)   //空節點
        return;

    TnodePtr left = node->left, right = node->right;
    delete node;
    deleteBtree(left);
    deleteBtree(right);
}

bool Btree::isPalindromicTree(){
    return areMirrors(root, root);
}