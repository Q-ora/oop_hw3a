姓名: 謝宗哲
學號: 408210005
email: steven900412@gmail.com
完成項目:
    1. 提示輸入
    2. 在Stack.h宣告destructor, 結束時會delete stack內的所有node
    3. 在Btree.h宣告三個成員函式:
        TnodePtr& getRoot();    //回傳root的reference
        void buildBtree(int val[], int n, int &k, TnodePtr &node);  //依照val陣列裡的內容建tree, val存treeNode.txt的一行的所有數字
        void deleteBtree(TnodePtr &node);   //delete tree的所有node
    4. 答案輸出到螢幕上
    5. 執行函式時, 輸出訊息來顯示目前的操作或狀態
Bonus:
    1. 回文樹的答案額外輸出到answer.txt
Reference:
    1. https://bbs.csdn.net/topics/340006356 複製了讀取每一行整數的迴圈來用, 有稍微修改一些地方