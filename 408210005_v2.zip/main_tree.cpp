#include "Tnode.h"
#include "Btree.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

int main()
{
    int val[100]={0}, n=0, i=0;
    ifstream infile("treeNode.txt");
    ofstream outfile("answer.txt");
    string line;
    stringstream ss;
    int testCnt = 1;

    //read numbers in each line
    while( getline(infile, line) ){
        ss.clear();
        ss << line;
        n = 0, i = 0;  //陣列長度歸零
        while(ss >> val[n]) n++;

        //construct a binary tree
        Btree btree;
        TnodePtr &root = btree.getRoot();
        btree.buildBtree(val, n, i, root);
        if(btree.isPalindromicTree()){
            cout << "is palindromic tree" << endl;
            outfile << "input " << testCnt++ << ":" << endl
                    << "is palindromic tree" << endl;
        }else{
            cout << "not palindromic tree" << endl;
            outfile << "input " << testCnt++ << ":" << endl
                    << "not palindromic tree" << endl;
        }
        //delete Btree
        btree.deleteBtree(root);
        cout << "Btree deleted" << endl;
        cout << endl;
    }

    return 0;
}