#include "Stack.h"
#include <iostream>
Stack::Stack(){
    top = 0;
    std::cout << "new stack built" << std::endl;
}

Stack::~Stack(){
    NodePtr cur = top;
    while(cur){
        top = top->next;
        delete cur;
        cur = top;
    }
    std::cout << "stack has been deleted" << std::endl;
}

void Stack::empty() const{
    if (top==0)
        std::cout << "true" << std::endl;
    else
        std::cout << "false" << std::endl;
}

void Stack::push(int element){
    if(!top){
        top = new Node(element, 0);
    }else{
        NodePtr newNode = new Node(element, top);
        top = newNode;
    }
    std::cout << "new element " << element << " insert" << std::endl;
}

int Stack::pop(){
    if(!top){
        std::cout << "no element in stack" << std::endl;
        return -1;
    }else{
        NodePtr newTop = top->next;
        int ret = top->item;
        delete top;
        top = newTop;
        std::cout << "pop " << ret << std::endl;
        return ret;
    }
}