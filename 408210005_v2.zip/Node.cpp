#include "Node.h"
#include <iostream>
Node::Node(int x, NodePtr t){
    item = x;
    next = t;
    std::cout << "new node built" << std::endl;
}