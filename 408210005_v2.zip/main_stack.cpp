#include <iostream>
#include "Node.h"
#include "Stack.h"
using namespace std;

int main()
{
    int input;
    Stack s;

    while(cout << "Please enter a number: " && cin >> input){
        if(input == -1){
            //delete all nodes in stack
            break;
        }else if(input == 1){   //push
            int element;
            cout << "Please input an element: " << endl;
            cin >> element;
            s.push(element);
        }else if(input == 2){   //pop
            s.pop();
        }else if(input == 3){   //empty
            s.empty();
        }
    }

    return 0;
}