#ifndef _BTREE_H_
#define _BTREE_H_

#include "Tnode.h"
class Btree { 
private: 
    TnodePtr root; 
    bool areMirrors(TnodePtr root1, TnodePtr root2);
public:
    TnodePtr& getRoot();
    void buildBtree(int val[], int n, int &k, TnodePtr &node);
    void deleteBtree(TnodePtr &node);
    bool isPalindromicTree();
};

#endif