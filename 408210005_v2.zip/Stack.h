#ifndef _STACK_H_
#define _STACK_H_

#include "Node.h"
class Stack { 
private:
    NodePtr top;
public:
    Stack();
    ~Stack();   //delete所有Node
    void empty() const;
    void push(int element);
    int pop();
};
//stack成長方向與linklist方向相反

#endif