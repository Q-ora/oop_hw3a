#ifndef _TNODE_H_
#define _TNODE_H_

class Tnode {
public:
    Tnode *left, *right;
    int val;
};

typedef Tnode* TnodePtr;

#endif