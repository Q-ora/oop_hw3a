#ifndef _NODE_H_
#define _NODE_H_

class Node {
public:
    int item;
    Node* next;
    Node(int x, Node* t);
};

typedef Node* NodePtr;

#endif